require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const { initWhatsApp, sendMessage, isConnected, getQR } = require('./services/whatsapp');
const { run, get, all } = require('./database/connection');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'jet-whatsapp-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// View engine (simple HTML rendering via res.sendFile)
app.set('views', path.join(__dirname, 'views'));

// Middleware cek login admin
function requireLogin(req, res, next) {
  if (req.session.admin) return next();
  res.redirect('/login');
}

// ==================== ROUTES ====================

// Halaman login
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const admin = await get(`SELECT * FROM admin_settings WHERE id = 1`);
  const bcrypt = require('bcryptjs');

  if (admin && username === admin.username && await bcrypt.compare(password, admin.password)) {
    req.session.admin = { username: admin.username };
    return res.redirect('/dashboard');
  }

  res.send(`<script>alert('Username atau password salah!'); window.location='/login';</script>`);
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Dashboard admin
app.get('/dashboard', requireLogin, async (req, res) => {
  const settings = await get(`SELECT * FROM admin_settings WHERE id = 1`);
  const customers = await all(`SELECT * FROM customers ORDER BY created_at DESC LIMIT 10`);
  const tickets = await all(`SELECT * FROM tickets ORDER BY created_at DESC LIMIT 10`);
  const waStatus = isConnected();

  res.send(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Dashboard - Jet Whatsapp</title>
      <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
      <div class="container">
        <nav class="navbar">
          <div class="logo">⚡ Jet Whatsapp</div>
          <div class="nav-right">
            <span class="status-badge ${waStatus ? 'online' : 'offline'}">${waStatus ? '● Online' : '○ Offline'}</span>
            <a href="/qr" class="btn btn-outline">QR Code</a>
            <a href="/settings" class="btn btn-outline">Pengaturan</a>
            <a href="/logout" class="btn btn-danger">Logout</a>
          </div>
        </nav>

        <div class="grid">
          <div class="card stat-card">
            <h3>Total Pelanggan</h3>
            <p class="big-number">${customers.length}</p>
            <a href="/customers" class="btn btn-sm">Lihat Semua</a>
          </div>
          <div class="card stat-card">
            <h3>Tiket Terbaru</h3>
            <p class="big-number">${tickets.length}</p>
            <a href="/tickets" class="btn btn-sm">Lihat Semua</a>
          </div>
          <div class="card stat-card">
            <h3>Status WhatsApp</h3>
            <p class="big-number">${waStatus ? 'Terhubung' : 'Belum Terhubung'}</p>
            <a href="/qr" class="btn btn-sm">Scan QR</a>
          </div>
        </div>

        <div class="section">
          <h2>Tiket Terbaru</h2>
          <table class="table">
            <thead>
              <tr><th>No HP</th><th>Subjek</th><th>Status</th><th>Tanggal</th></tr>
            </thead>
            <tbody>
              ${tickets.map(t => `
                <tr>
                  <td>${t.phone}</td>
                  <td>${t.subject}</td>
                  <td><span class="badge badge-${t.status}">${t.status}</span></td>
                  <td>${t.created_at}</td>
                </tr>
              `).join('') || '<tr><td colspan="4">Belum ada tiket</td></tr>'}
            </tbody>
          </table>
        </div>

        <div class="section">
          <h2>Pelanggan Terbaru</h2>
          <table class="table">
            <thead>
              <tr><th>Nama</th><th>No HP</th><th>Jenis</th><th>Area</th></tr>
            </thead>
            <tbody>
              ${customers.map(c => `
                <tr>
                  <td>${c.name}</td>
                  <td>${c.phone}</td>
                  <td>${c.customer_type}</td>
                  <td>${c.service_area || '-'}</td>
                </tr>
              `).join('') || '<tr><td colspan="4">Belum ada pelanggan</td></tr>'}
            </tbody>
          </table>
        </div>

        <div class="quick-actions">
          <h2>Aksi Cepat</h2>
          <div class="action-grid">
            <a href="/customers/import" class="btn btn-primary">Import CSV Pelanggan</a>
            <a href="/settings" class="btn btn-primary">Pengaturan API Key</a>
            <a href="/qr" class="btn btn-primary">Koneksi WhatsApp</a>
          </div>
        </div>
      </div>
    </body>
    </html>
  `);
});

// QR Code WhatsApp
app.get('/qr', requireLogin, (req, res) => {
  const qr = getQR();
  res.send(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>QR Code - Jet Whatsapp</title>
      <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
      <div class="container">
        <nav class="navbar">
          <div class="logo">⚡ Jet Whatsapp</div>
          <a href="/dashboard" class="btn btn-outline">Kembali</a>
        </nav>
        <div class="card" style="max-width: 400px; margin: 2rem auto; text-align: center;">
          <h2>Scan QR Code WhatsApp</h2>
          <p>Gunakan WhatsApp di ponsel: Menu → Perangkat Tertaut → Tombol +</p>
          ${qr ? `<div id="qrcode">${qr}</div>` : '<p>QR Code belum tersedia, silakan restart WhatsApp service.</p>'}
          <br>
          <a href="/dashboard" class="btn btn-primary">Kembali ke Dashboard</a>
        </div>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
      <script>
        if (${qr ? 'true' : 'false'}) {
          new QRCode(document.getElementById("qrcode"), {
            text: JSON.stringify(${JSON.stringify(qr)}),
            width: 256,
            height: 256
          });
        }
      </script>
    </body>
    </html>
  `);
});

// Pengaturan admin (API key, dll)
app.get('/settings', requireLogin, async (req, res) => {
  const settings = await get(`SELECT * FROM admin_settings WHERE id = 1`);
  res.send(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>Pengaturan - Jet Whatsapp</title>
      <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
      <div class="container">
        <nav class="navbar">
          <div class="logo">⚡ Jet Whatsapp</div>
          <a href="/dashboard" class="btn btn-outline">Kembali</a>
        </nav>
        <div class="card" style="max-width: 600px; margin: 2rem auto;">
          <h2>Pengaturan Admin</h2>
          <form action="/settings" method="POST">
            <div class="form-group">
              <label>Bot Name</label>
              <input type="text" name="bot_name" value="${settings.bot_name || 'Jet Whatsapp'}" required>
            </div>
            <div class="form-group">
              <label>API Key Bankai (AI)</label>
              <input type="text" name="api_key" value="${settings.api_key || ''}" placeholder="Masukkan API key Bankai">
            </div>
            <div class="form-group">
              <label>Nomor Escalasi Admin</label>
              <input type="text" name="escalation_phone" value="${settings.escalation_phone || ''}" placeholder="08xxxxxxxxxx">
            </div>
            <div class="form-group">
              <label>AI Enabled</label>
              <select name="ai_enabled">
                <option value="1" ${settings.ai_enabled ? 'selected' : ''}>Aktif</option>
                <option value="0" ${!settings.ai_enabled ? 'selected' : ''}>Nonaktif</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
          </form>
        </div>
      </div>
    </body>
    </html>
  `);
});

app.post('/settings', requireLogin, async (req, res) => {
  const { bot_name, api_key, escalation_phone, ai_enabled } = req.body;
  await run(
    `UPDATE admin_settings SET bot_name = ?, api_key = ?, escalation_phone = ?, ai_enabled = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1`,
    [bot_name, api_key, escalation_phone, ai_enabled]
  );
  res.send(`<script>alert('Pengaturan disimpan!'); window.location='/settings';</script>`);
});

// Kelola pelanggan
app.get('/customers', requireLogin, async (req, res) => {
  const customers = await all(`SELECT * FROM customers ORDER BY name ASC`);
  res.send(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>Pelanggan - Jet Whatsapp</title>
      <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
      <div class="container">
        <nav class="navbar">
          <div class="logo">⚡ Jet Whatsapp</div>
          <a href="/dashboard" class="btn btn-outline">Kembali</a>
        </nav>
        <div class="card">
          <h2>Daftar Pelanggan</h2>
          <a href="/customers/import" class="btn btn-primary" style="float: right;">Import CSV</a>
          <table class="table">
            <thead>
              <tr><th>Nama</th><th>No HP</th><th>Jenis</th><th>Area</th><th>Aksi</th></tr>
            </thead>
            <tbody>
              ${customers.map(c => `
                <tr>
                  <td>${c.name}</td>
                  <td>${c.phone}</td>
                  <td>${c.customer_type}</td>
                  <td>${c.service_area || '-'}</td>
                  <td>
                    <a href="/customers/delete/${c.id}" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</a>
                  </td>
                </tr>
              `).join('') || '<tr><td colspan="5">Belum ada pelanggan</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </body>
    </html>
  `);
});

// Import CSV
app.get('/customers/import', requireLogin, (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>Import CSV - Jet Whatsapp</title>
      <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
      <div class="container">
        <nav class="navbar">
          <div class="logo">⚡ Jet Whatsapp</div>
          <a href="/customers" class="btn btn-outline">Kembali</a>
        </nav>
        <div class="card" style="max-width: 600px; margin: 2rem auto;">
          <h2>Import Kontak Pelanggan via CSV</h2>
          <p>Format CSV dengan kolom: <code>nama,no_whatsapp,jenis_pelanggan,area_layanan</code></p>
          <p>Jenis pelanggan: <code>pppoe</code> atau <code>member_hotspot</code></p>
          <form action="/customers/import" method="POST" enctype="multipart/form-data">
            <div class="form-group">
              <label>Pilih file CSV</label>
              <input type="file" name="csv_file" accept=".csv" required>
            </div>
            <button type="submit" class="btn btn-primary">Import</button>
          </form>
        </div>
      </div>
    </body>
    </html>
  `);
});

const upload = multer({ dest: 'uploads/' });
app.post('/customers/import', requireLogin, upload.single('csv_file'), async (req, res) => {
  const fs = require('fs');
  const csv = require('csv-parse/sync');
  const fileContent = fs.readFileSync(req.file.path);
  const records = csv.parse(fileContent, { columns: true, skip_empty_lines: true });

  let success = 0;
  let error = 0;

  for (const row of records) {
    try {
      await run(
        `INSERT OR IGNORE INTO customers (name, phone, customer_type, service_area) VALUES (?, ?, ?, ?)`,
        [row.nama, row.no_whatsapp, row.jenis_pelanggan, row.area_layanan]
      );
      success++;
    } catch (e) {
      error++;
    }
  }

  fs.unlinkSync(req.file.path);
  res.send(`<script>alert('Import selesai! Berhasil: ${success}, Gagal: ${error}'); window.location='/customers';</script>`);
});

app.get('/customers/delete/:id', requireLogin, async (req, res) => {
  await run(`DELETE FROM customers WHERE id = ?`, [req.params.id]);
  res.redirect('/customers');
});

// Tiket
app.get('/tickets', requireLogin, async (req, res) => {
  const tickets = await all(`SELECT * FROM tickets ORDER BY created_at DESC`);
  res.send(`
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>Tiket - Jet Whatsapp</title>
      <link rel="stylesheet" href="/css/style.css">
    </head>
    <body>
      <div class="container">
        <nav class="navbar">
          <div class="logo">⚡ Jet Whatsapp</div>
          <a href="/dashboard" class="btn btn-outline">Kembali</a>
        </nav>
        <div class="card">
          <h2>Daftar Tiket Ganguan</h2>
          <table class="table">
            <thead>
              <tr><th>No HP</th><th>Subjek</th><th>Status</th><th>AI Response</th><th>Tanggal</th></tr>
            </thead>
            <tbody>
              ${tickets.map(t => `
                <tr>
                  <td>${t.phone}</td>
                  <td>${t.subject}</td>
                  <td><span class="badge badge-${t.status}">${t.status}</span></td>
                  <td>${(t.ai_response || '-').substring(0, 50)}...</td>
                  <td>${t.created_at}</td>
                </tr>
              `).join('') || '<tr><td colspan="5">Belum ada tiket</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </body>
    </html>
  `);
});

// API endpoint untuk integrasi web/app lain
app.get('/api/customers/:phone', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  const settings = await get(`SELECT * FROM admin_settings WHERE id = 1`);

  if (settings.api_key && apiKey !== settings.api_key) {
    return res.status(401).json({ error: 'API key tidak valid' });
  }

  const customer = await get(`SELECT * FROM customers WHERE phone = ?`, [req.params.phone]);
  if (!customer) return res.status(404).json({ error: 'Pelanggan tidak ditemukan' });

  res.json(customer);
});

// Kirim pesan via API
app.post('/api/send-message', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  const settings = await get(`SELECT * FROM admin_settings WHERE id = 1`);

  if (settings.api_key && apiKey !== settings.api_key) {
    return res.status(401).json({ error: 'API key tidak valid' });
  }

  const { phone, message } = req.body;
  if (!phone || !message) return res.status(400).json({ error: 'Phone dan message wajib diisi' });

  try {
    await sendMessage(phone, message);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 404
app.use((req, res) => {
  res.status(404).send('Halaman tidak ditemukan - Jet Whatsapp');
});

// Start server dan inisialisasi WhatsApp
app.listen(PORT, async () => {
  console.log(`🚀 Jet Whatsapp berjalan di http://localhost:${PORT}`);
  console.log(`📊 Panel Admin: http://localhost:${PORT}/login`);
  console.log(`🔐 Login default: admin / 12345678`);
  await initWhatsApp();
});