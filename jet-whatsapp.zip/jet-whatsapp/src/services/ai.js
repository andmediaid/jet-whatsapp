const axios = require('axios');

class AiService {
  constructor() {
    this.baseURL = 'https://bankai.web.id/api';
    this.apiKey = process.env.BANKAI_API_KEY || ''; // Masukkan API key Anda di sini atau lewat .env
    this.timeout = 15000;
  }

  /**
   * Kirim pertanyaan ke AI Bankai untuk troubleshooting
   */
  async askAI(customer, message, settings) {
    try {
      const prompt = `
Anda adalah asisten teknis support internet (ISP) untuk Jet Whatsapp.
Data pelanggan:
- Nama: ${customer.name}
- Jenis pelanggan: ${customer.customer_type}
- Area layanan: ${customer.service_area}

Keluhan pelanggan: ${message}

Tugas Anda:
1. Berikan troubleshooting awal (langkah-langkah sederhana yang bisa dilakukan pelanggan sendiri).
2. Jika masalah bisa diatasi oleh pelanggan, berikan solusi langsung.
3. Jika AI tidak yakin atau memerlukan intervensi teknis/admin, tandai dengan "ESCALATE: true" di akhir respons.
4. Gunakan bahasa Indonesia, ramah, dan jelas.

Format respons:
[Troubleshooting]
...
[ESCALATE: true/false]
      `;

      const response = await axios.post(
        `${this.baseURL}/chat`,
        {
          api_key: this.apiKey,
          message: prompt,
          customer: customer.name,
          type: customer.customer_type
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.apiKey}`
          },
          timeout: this.timeout
        }
      );

      const aiText = response.data.response || response.data.text || response.data.message || JSON.stringify(response.data);
      const escalate = aiText.includes('ESCALATE: true') || response.data.escalate === true;

      return {
        response: aiText.replace(/ESCALATE:\s*(true|false)/gi, '').trim(),
        escalate: escalate
      };
    } catch (err) {
      console.error('❌ AI Error:', err.message);
      return {
        response: `Maaf, sistem AI sedang tidak tersedia. Silakan coba lagi nanti atau ketik *menu* untuk hubungi admin manusia.`,
        escalate: true
      };
    }
  }

  /**
   * Handle troubleshooting alur lengkap
   */
  async handleTroubleshooting(customer, message, settings) {
    // Deteksi kata kunci ganguan untuk menentukan apakah perlu AI
    const ganguanKeywords = ['ganguan', 'mati', 'lemput', 'tidak bisa', 'putus', 'error', 'tidak ada internet', 'lambat'];
    const isGanguan = ganguanKeywords.some(k => message.toLowerCase().includes(k));

    if (!isGanguan) {
      return {
        response: `Halo ${customer.name}! Ada yang bisa kami bantu?\n\nKetik *menu* untuk melihat opsi layanan.\n\nAtau jelaskan ganguan internet yang Anda alami agar kami bisa bantu troubleshooting.`,
        escalate: false
      };
    }

    return await this.askAI(customer, message, settings);
  }
}

module.exports = AiService;