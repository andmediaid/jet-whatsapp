const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@adiwajshing/baileys');
const pino = require('pino');
const path = require('path');
const { run, get, all } = require('../database/connection');
const AiService = require('./ai');

let sock = null;
let isConnected = false;
let qrCode = null;

const aiService = new AiService();

// Menu opsi pelanggan (dikonfigurasi dari admin_settings nanti)
const DEFAULT_MENU = `
📋 *Menu Jet Whatsapp*

Pilih opsi dengan mengetik nomor:

1️⃣ Laporan Ganguan Internet
2️⃣ Cek Status Tiket / Ganguan
3️⃣ Info Paket & Area Layanan
4️⃣ Hubungi Admin Manusia
5️⃣ Bantuan Umum / FAQ

Ketik nomor opsi (1-5) untuk melanjutkan.
`;

/**
 * Inisialisasi koneksi WhatsApp dengan Baileys
 */
async function initWhatsApp() {
  try {
    const authStatePath = path.join(__dirname, '..', 'database', 'auth_info_baileys');
    const { state, saveCreds } = await useMultiFileAuthState(authStatePath);

    const { version } = await fetchLatestBaileysVersion();

    sock = makeWASocket({
      version,
      logger: pino({ level: 'silent' }),
      printQRInTerminal: false,
      auth: state,
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
      const { connection, qr } = update;
      if (qr) {
        qrCode = qr;
        isConnected = false;
        console.log('📱 QR Code siap dipindai. Gunakan /qr di panel admin atau lihat terminal.');
      }
      if (connection === 'open') {
        isConnected = true;
        qrCode = null;
        console.log('✅ WhatsApp terhubung!');
      }
      if (connection === 'close') {
        isConnected = false;
        console.log('⚠️ WhatsApp terputus, mencoba menghubungkan kembali...');
      }
    });

    // Handler pesan masuk
    sock.ev.on('messages.upsert', async (event) => {
      const msg = event.messages[0];
      if (!msg || !msg.message) return;
      if (msg.key.fromMe) return; // abaikan pesan sendiri

      const phone = msg.key.remoteJid?.replace('@s.whatsapp.net', '');
      const text = extractText(msg.message);

      if (!phone || !text) return;

      await handleIncomingMessage(phone, text);
    });

    console.log('🔄 Baileys diinisialisasi. Menunggu scan QR...');
  } catch (err) {
    console.error('❌ Gagal inisialisasi WhatsApp:', err.message);
  }
}

/**
 * Ekstrak teks dari berbagai tipe pesan WhatsApp
 */
function extractText(message) {
  if (message.conversation) return message.conversation;
  if (message.extendedTextMessage) return message.extendedTextMessage.text;
  if (message.imageMessage) return message.imageMessage.caption || '[Gambar]';
  if (message.videoMessage) return message.videoMessage.caption || '[Video]';
  if (message.documentMessage) return message.documentMessage.caption || '[Dokumen]';
  if (message.audioMessage) return '[Audio]';
  if (message.stickerMessage) return '[Stiker]';
  return '';
}

/**
 * Kirim pesan WhatsApp
 */
async function sendMessage(phone, text) {
  if (!sock || !isConnected) {
    throw new Error('WhatsApp belum terhubung');
  }

  const jid = phone.includes('@') ? phone : `${phone}@s.whatsapp.net`;
  await sock.sendMessage(jid, { text });
  return true;
}

/**
 * Handler utama pesan masuk
 */
async function handleIncomingMessage(phone, text) {
  const trimmed = text.trim();

  // Simpan pesan masuk ke database
  await run(
    `INSERT INTO conversations (phone, message, direction) VALUES (?, ?, 'incoming')`,
    [phone, trimmed]
  );

  // Cari pelanggan di database
  const customer = await get(`SELECT * FROM customers WHERE phone = ?`, [phone]);
  const settings = await get(`SELECT * FROM admin_settings WHERE id = 1`);

  if (!customer) {
    // Di luar database -> WhatsApp berfungsi normal (balas otomatis sederhana atau biarkan admin)
    await sendMessage(phone, `Halo! Nomor Anda ${phone} belum terdaftar dalam sistem pelanggan Jet Whatsapp.\n\nUntuk layanan, silakan hubungi admin atau daftar di kantor kami.\n\nKetik *menu* untuk melihat opsi bantuan.`);
    return;
  }

  // Pelanggan terdaftar - proses dengan AI / menu
  const lower = trimmed.toLowerCase();

  // Jika user mengetik "menu" atau angka opsi
  if (lower === 'menu' || lower === 'start' || lower === 'halo' || lower === 'hi') {
    await sendMessage(phone, DEFAULT_MENU);
    return;
  }

  // Pilihan opsi menu
  const menuOptions = {
    '1': 'lapor_ganguan',
    '2': 'cek_status',
    '3': 'info_paket',
    '4': 'hubungi_admin',
    '5': 'bantuan_umum'
  };

  if (menuOptions[lower]) {
    await handleMenuOption(phone, customer, menuOptions[lower], settings);
    return;
  }

  // Jika AI enabled dan bukan opsi menu, coba troubleshooting dengan AI
  if (settings && settings.ai_enabled) {
    const aiResult = await aiService.handleTroubleshooting(customer, trimmed, settings);
    
    if (aiResult.escalate) {
      // Escalasi ke admin
      await run(
        `UPDATE conversations SET escalated = 1 WHERE phone = ? ORDER BY created_at DESC LIMIT 1`,
        [phone]
      );
      await run(
        `INSERT INTO tickets (phone, customer_id, subject, description, status, ai_response) VALUES (?, ?, ?, ?, 'escalated', ?)`,
        [phone, customer.id, 'Escalasi dari AI chat', trimmed, aiResult.response]
      );
      await sendMessage(phone, aiResult.response);
      await sendMessage(phone, `🔄 Permintaan Anda telah diteruskan ke admin manusia. Admin akan menghubungi Anda di nomor ${settings.escalation_phone || 'admin'}.\n\nKetik *menu* untuk kembali ke menu utama.`);
    } else {
      await sendMessage(phone, aiResult.response);
    }
  } else {
    await sendMessage(phone, `Halo ${customer.name}! Terima kasih telah menghubungi Jet Whatsapp.\n\nKetik *menu* untuk melihat opsi layanan yang tersedia.`);
  }
}

/**
 * Handle opsi menu yang dipilih pelanggan
 */
async function handleMenuOption(phone, customer, option, settings) {
  switch (option) {
    case 'lapor_ganguan':
      await sendMessage(phone, `📋 *Laporan Ganguan*\n\nHalo ${customer.name}, silakan jelaskan ganguan yang Anda alami (misal: internet tidak ada, lemput, putus-putus, dll).\n\nAI kami akan memberikan troubleshooting awal. Jika tidak terpecahkan, akan diteruskan ke admin.`);
      break;

    case 'cek_status':
      const tickets = await all(`SELECT * FROM tickets WHERE phone = ? ORDER BY created_at DESC LIMIT 3`, [phone]);
      if (tickets.length === 0) {
        await sendMessage(phone, 'Belum ada tiket ganguan yang tercatat. Ketik *menu* untuk kembali.');
      } else {
        let text = '📋 *Status Tiket Terbaru:*\n\n';
        tickets.forEach((t, i) => {
          text += `${i + 1}. ${t.subject}\n   Status: ${t.status}\n   Tanggal: ${t.created_at}\n\n`;
        });
        text += 'Ketik *menu* untuk kembali.';
        await sendMessage(phone, text);
      }
      break;

    case 'info_paket':
      await sendMessage(phone, `ℹ️ *Info Paket & Area*\n\nNama: ${customer.name}\nJenis: ${customer.customer_type === 'pppoe' ? 'PPPoE' : 'Member Hotspot'}\nArea: ${customer.service_area || '-'}\n\nKetik *menu* untuk kembali.`);
      break;

    case 'hubungi_admin':
      await sendMessage(phone, `📞 *Hubungi Admin*\n\nSilakan hubungi admin manusia di nomor: ${settings.escalation_phone || '08xxxxxxxxxx'}\n\nKetik *menu* untuk kembali.`);
      break;

    case 'bantuan_umum':
      await sendMessage(phone, `❓ *Bantuan Umum*\n\n- Pastikan modem/router nyala\n- Coba restart perangkat\n- Periksa kabel jaringan\n- Jika masih ganguan, pilih opsi 1 untuk melaporkan\n\nKetik *menu* untuk kembali.`);
      break;

    default:
      await sendMessage(phone, `Opsi tidak dikenali. Ketik *menu* untuk melihat opsi yang tersedia.`);
  }
}

module.exports = { initWhatsApp, sendMessage, isConnected: () => isConnected, getQR: () => qrCode, getSock: () => sock };