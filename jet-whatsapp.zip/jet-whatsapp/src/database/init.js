const path = require('path');
const Database = require('sqlite3').Database;
const dbPath = path.join(__dirname, 'jet_whatsapp.db');

const db = new Database(dbPath, (err) => {
  if (err) {
    console.error('❌ Gagal membuka database:', err.message);
  } else {
    console.log('✅ Terhubung ke database SQLite:', dbPath);
  }
});

db.serialize(() => {
  // Tabel pelanggan
  db.run(`
    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      customer_type TEXT CHECK(customer_type IN ('pppoe','member_hotspot')) NOT NULL,
      service_area TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabel admin settings (login, API key, dll)
  db.run(`
    CREATE TABLE IF NOT EXISTS admin_settings (
      id INTEGER PRIMARY KEY DEFAULT 1,
      username TEXT NOT NULL DEFAULT 'admin',
      password TEXT NOT NULL,
      api_key TEXT,
      bot_name TEXT DEFAULT 'Jet Whatsapp',
      ai_enabled INTEGER DEFAULT 1,
      escalation_phone TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabel percakapan (untuk tracking chat pelanggan)
  db.run(`
    CREATE TABLE IF NOT EXISTS conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      customer_id INTEGER,
      message TEXT,
      direction TEXT CHECK(direction IN ('incoming','outgoing')) NOT NULL,
      is_ai_handled INTEGER DEFAULT 0,
      escalated INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
  `);

  // Tabel tiket ganguan (troubleshooting)
  db.run(`
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      customer_id INTEGER,
      subject TEXT,
      description TEXT,
      status TEXT CHECK(status IN ('open','ai_handling','escalated','resolved','closed')) DEFAULT 'open',
      ai_response TEXT,
      admin_note TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id)
    )
  `);

  // Seed default admin (password: 12345678)
  const bcrypt = require('bcryptjs');
  const defaultPassword = bcrypt.hashSync('12345678', 10);

  db.run(
    `INSERT OR IGNORE INTO admin_settings (id, username, password) VALUES (1, 'admin', ?)`,
    [defaultPassword],
    (err) => {
      if (err) console.error('❌ Gagal seed admin:', err.message);
      else console.log('✅ Admin default dibuat (username: admin, password: 12345678)');
    }
  );

  db.close((err) => {
    if (err) console.error('❌ Gagal menutup database:', err.message);
    else console.log('✅ Database siap digunakan.');
  });
});

module.exports = dbPath;