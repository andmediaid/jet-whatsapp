const path = require('path');
const Database = require('sqlite3').Database;

const dbPath = path.join(__dirname, 'jet_whatsapp.db');

const db = new Database(dbPath, (err) => {
  if (err) {
    console.error('❌ Gagal membuka database:', err.message);
  }
});

// Wrapper untuk query dengan Promise
function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

module.exports = { db, run, get, all };