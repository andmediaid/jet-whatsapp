# Jet Whatsapp

WhatsApp Gateway dengan identifikasi pelanggan, panel admin, API key, import CSV, dan AI troubleshooting otomatis.

## Fitur

- ✅ Identifikasi pelanggan berdasarkan nomor HP terdaftar di database
- ✅ Jika nomor di luar database → WhatsApp berfungsi normal
- ✅ Panel admin menarik dengan login username/password
- ✅ Pengaturan API Key untuk integrasi web/app lain
- ✅ Import kontak pelanggan via CSV (nama, no whatsapp, jenis pelanggan, area layanan)
- ✅ AI chat otomatis untuk troubleshooting ganguan (via Bankai API)
- ✅ Escalasi ke admin manusia jika AI tidak dapat menyelesaikan
- ✅ Menu opsi pelanggan saat menghubungi nomor bot
- ✅ Endpoint API untuk integrasi eksternal

## Instalasi

```bash
cd jet-whatsapp
npm install
```

### Setup Database

```bash
npm run init-db
```

### Konfigurasi

Edit file `.env` dan masukkan API Key Bankai Anda:

```
BANKAI_API_KEY=MASUKKAN_API_KEY_ANDA_DISINI
```

### Jalankan

```bash
npm start
```

Akses panel admin: `http://localhost:3000/login`

Login default:
- Username: `admin`
- Password: `12345678`

## Teknologi

- Node.js + Express
- Baileys (WhatsApp Web)
- SQLite
- Bankai AI API

## Struktur Folder

```
jet-whatsapp/
├── src/
│   ├── server.js          # Entry point
│   ├── routes/            # Route admin & API
│   ├── services/          # WhatsApp & AI service
│   ├── database/          # SQLite connection & init
│   ├── views/             # HTML views
│   └── public/            # CSS & JS
├── .env                   # Konfigurasi
├── package.json
└── README.md
```

## Catatan Hosting

Untuk hosting biasa (shared hosting), pastikan support Node.js. Jika tidak tersedia, gunakan VPS.

Scan QR Code WhatsApp melalui panel admin untuk menghubungkan nomor bot.